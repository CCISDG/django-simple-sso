default_app_config = 'simple_sso.sso_server.apps.SimpleSSOServer'
