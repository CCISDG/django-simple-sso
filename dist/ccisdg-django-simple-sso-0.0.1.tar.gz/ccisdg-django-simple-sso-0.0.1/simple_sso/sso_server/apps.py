from django.apps import AppConfig


class SimpleSSOServer(AppConfig):
    name = 'simple_sso.sso_server'
